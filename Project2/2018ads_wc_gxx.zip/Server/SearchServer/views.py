"""
Routes and views for the flask application.
"""

from . import routes