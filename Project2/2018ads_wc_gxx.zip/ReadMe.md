# ReadMe
## requirements
you can see all the requirements in './server/requirements.txt', then you can install them by pip.
## web server run
python run_server.py
the web server will run, and you can browse the page in your browser.
## python script
change the sentence you want to search in main.py, and then
python main.py

